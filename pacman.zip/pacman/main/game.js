let gm = new GameMap;
gm.render();
// gm.bomb_render();
