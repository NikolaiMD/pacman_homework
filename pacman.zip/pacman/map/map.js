const VOID = 0;
const PACMAN = 1;
const CHERRY = 2;
const BOMB = 3;
const COIN = 4;
var pac_direction = "right";
var pac_position=Math.floor(Math.random() * 9);
var bomb_position=Math.floor(Math.random() * 9);
var cherry_position=Math.floor(Math.random() * 9);
var coin_position=Math.floor(Math.random() * 9);
pac_position!=bomb_position!=cherry_position!=coin_position;
var pac_explosion = false;
var health = 100;
var score = 0;
function end_explosion(){
  pac_explosion=false;
  gm.render;
}
class GameMap {
  constructor() {
    // this.grid.indexOf(PACMAN)=1;
    this.grid = [VOID,VOID,VOID,VOID,VOID,VOID,VOID,VOID,VOID,VOID];
    var removed1 = this.grid.splice(bomb_position, 1, BOMB);
    var removed2 = this.grid.splice(cherry_position, 1, CHERRY);
    var removed3 = this.grid.splice(coin_position, 1, COIN);
    var removed = this.grid.splice(pac_position, 1, PACMAN);
    // this.grid[BOMB]=pac_bomb;
    // this.grid[CHERRY]=pac_cherry;
    // this.grid[COIN]=pac_coin;
    // this.grid[PACMAN]=pac_position;
  }
  render(){
    let info = document.getElementById('info');
    let hud_html = `<div id="health">${health}</div><div id="score">${score}</div>`;
    let div = document.getElementById('map');
    let html = ``;
    for(var i=0; i<=9; i++){
      var c = '';
      switch (this.grid[i]) {
        case VOID: break;
        case PACMAN: c='pacman';
          if(pac_direction=="up"){
            c+=' up';
          }
          if(pac_direction=="down"){
            c+=' down';
          }
          if(pac_direction=="left"){
            c+=' left';
          }
          if(pac_explosion==true){
            c+=' explosion';
            setTimeout(end_explosion, 1000);
          }
          break;
        case CHERRY: c='cherry';break;
        case BOMB: c='bomb';break;
        case COIN: c='coin';break;
      }
      html+=`<div class="${c}"></div>`
    }
    div.innerHTML = html;
    info.innerHTML = hud_html;
  }
  action(){
    // if(event.code=="ArrowUp"){
    //   pac_direction="up";
    //   this.moveUp();
    // }
    if(event.code=="ArrowRight"&&pac_position<9){
      pac_position=pac_position+1;
      pac_direction="right";
      this.moveRight();
    }
    // if(event.code=="ArrowDown"){
    //   pac_direction="down";
    //   this.moveDown();
    // }
    if(event.code=="ArrowLeft"&&pac_position>0){
      pac_position=pac_position-1;
      pac_direction="left";
      this.moveLeft();
    }
    // console.log(event.code);
  }
  moveLeft(){
   // pac_position=
    var index = this.grid.indexOf(PACMAN);
    this.grid[index]=VOID;
    if(this.grid[index-1]==BOMB){
      health=health-50;
    }
    if(this.grid[index-1]==BOMB&&health<50){
      pac_explosion=true;
    }
    if(health==0){
      alert("DEAD");
    }
    if(this.grid[index-1]==COIN){
      score=score+25;
    }
    if(this.grid[index-1]==CHERRY){
      health=health+25;
    }
    this.grid[index-1]=PACMAN;
    this.render();
  }
  moveRight(){
    var index = this.grid.indexOf(PACMAN);
    this.grid[index]=VOID;
    if(this.grid[index+1]==BOMB){
      health=health-50;
    }
    if(this.grid[index+1]==BOMB&&health<50){
      pac_explosion=true;
    }
    if(health==0){
      alert("DEAD");
    }
    if(this.grid[index+1]==COIN){
      score=score+25;
    }
    if(this.grid[index+1]==CHERRY){
      health=health+50;
    }
    this.grid[index+1]=PACMAN;
    this.render();
  }
}
// moveDown(){
  //   var index = this.grid.indexOf(PACMAN);
  //   this.grid[index]=VOID;
  //   if(this.grid[index+10]==BOMB){
    //     health=health-50;
    //   }
    //   if(this.grid[index+10]==BOMB&&health<50){
      //     pac_explosion=true;
      //   }
      //   if(health==0){
        //     alert("DEAD");
        //   }
        //   if(this.grid[index+10]==COIN){
          //     score=score+25;
          //   }
          //   if(this.grid[index+10]==CHERRY){
            //     health=health+50;
            //   }
            //   this.grid[index+10]=PACMAN;
            //   this.render();
            // }
            // moveUp(){
              //   var index = this.grid.indexOf(PACMAN);
              //   // var
              //   // if(this.render.i<0&&this.render.i>99){
                //   //   this.grid[index]=this.grid[index];
                //   // }
                //   this.grid[index]=VOID;
                //   if(this.grid[index-10]==BOMB){
                  //     health=health-50;
                  //   }
                  //   if(this.grid[index-10]==BOMB&&health<50){
                    //     pac_explosion=true;
                    //   }
                    //   if(health==0){
                      //     alert("DEAD");
                      //   }
                      //   if(this.grid[index-10]==COIN){
                        //     score=score+25;
                        //   }
                        //   if(this.grid[index-10]==CHERRY){
                          //     health=health+50;
                          //   }
                          //   this.grid[index-10]=PACMAN;
                          //   this.render();
                          // }
